/*******************************************************************************
  * File Name          : mxconstants.h
  * Description        : This file contains the common defines of the application
  *****************************************************************************/


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
